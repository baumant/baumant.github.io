var smg = smg || {};

// Prevent errors
var _gaq = _gaq || [];
var CLARITY = CLARITY || [];

(function($){

    smg.isTouch = 'ontouchstart' in window || navigator.msMaxTouchPoints;

    smg.common = {

        counter : 0,

        init_ad_scrolling: function(Ads) {
            var $sidebarAdHolder = $(".sidebar > div").last().filter(".sm-widget-ad-holder");

            if(!$sidebarAdHolder.length)
                return;

            var $leftCol = $('.main-container .left-col').last(),
                $sidebarAd = $sidebarAdHolder.find(".sm-widget-ad:last"),
                sidebarAdHolderTop = $sidebarAdHolder.offset().top,
                scrollConfig = {
                    $boundingEl: $sidebarAdHolder
                },
                calcAdHolderHeight = function () {
                    return ($leftCol.outerHeight() + $leftCol.offset().top) - $sidebarAdHolder.offset().top;
                },
                sidebarAdHolderHeight = calcAdHolderHeight();

            // If there's no space, don't scroll
            if(sidebarAdHolderHeight <= 300) {
                return;
            }

            // Set ad holder height and start scrolling
            $sidebarAdHolder.css('height', sidebarAdHolderHeight);
            $sidebarAd.addClass('sticky-ad').smgScrollAttach(scrollConfig);

            // Recalculate things every time an iframe loads, since it might be an ad
            document.addEventListener(
                'load', 
                function(e) {
                    if(e.target.nodeName === "IFRAME") {
                        var scrollAttach = $sidebarAd.data('smgScrollAttach'),
                            holderHeight;

                        if(scrollAttach) {
                            scrollAttach.calcBounds(); 
                        }
                        holderHeight = calcAdHolderHeight();

                        if(holderHeight <= 300 || holderHeight <= $sidebarAd.outerHeight()) {
                            scrollAttach.off();
                            // update size if content height changed
                            $sidebarAd.removeClass('sticky-ad');
                            $sidebarAdHolder.css('height', 'auto');
                            return;
                        }

                        $sidebarAdHolder.css('height', holderHeight);
                        sidebarAdHolderTop = $sidebarAdHolder.offset().top;
                    } 
                }, 
                true
            );
        },

        init_search_hover: function() {
            // Header menu search
            var $searchHolder = $('#menu .search'),
                $headerSearch = $searchHolder.find('#header-search'),
                $searchSubmit = $headerSearch.find('.search-submit');
                $searchQuery = $headerSearch.find('input[name="s"]');

            // Stop propogation if click events
            $searchHolder.on('click', function(e){
                return false;
            });
            $searchSubmit
                .click(function(e){
                    if($searchHolder.hasClass('open')) {
                        if($searchQuery.val() != '') {
                            $headerSearch.submit();
                        } else {
                            $searchHolder.removeClass('open');
                        }
                    } else {
                        $searchHolder.addClass('open');
                        $searchQuery.focus();

                        // Close search box if they clicked away
                        $(document).one('click', function(e){ $searchHolder.removeClass('open'); });
                        return false;
                    }
                });
            $searchQuery
                .keydown(function(e){
                    if(e.keyCode == 13) {
                        e.preventDefault();
                        $headerSearch.submit();
                    }
                });
        },

        init_social : function() {
            // Setup FB for like button but check if it exists first
            if (typeof FB === 'undefined') {
                if (document.getElementById('facebook-jssdk')) {
                    return;
                }
                window.createScript('//connect.facebook.net/en_US/all.js#xfbml=1');
            }
            else {
                FB.XFBML.parse();
            }

            // Setup hover state for menu
            $('.more-social-icons').on('hover', function () {
                $(this).addClass('active');
                $("body :not(.social-links, .social-links *)").on('hover', function (e) {
                    $('.more-social-icons').removeClass('active');
                });
            });

            // Setup hover state for in article social links
            $('.social-icons .icon-plus').on('click', function () {
                if ($(this).parents('.social-container.active').length) {
                    $(this).parents('.social-container').removeClass('active');
                } else {
                    $(this).parents('.social-container').addClass('active');
                }
            });
        },

        init_social_scrolling: function() {
            // Init footer social show/hide
            var $socialIcons = $('.social-icons.post-header');

            if ($socialIcons.length) {
                smg.common.check_social_icon_position($socialIcons);
                $(window).scroll( function() {
                    smg.common.check_social_icon_position($socialIcons);
                });
            }

            var $featuredSocialIcons = $('.featured-social-icons.post-header');
            if ($featuredSocialIcons.length) {
                smg.common.check_featured_social_icon_position($featuredSocialIcons);
                $(window).scroll( function() {
                    smg.common.check_featured_social_icon_position($featuredSocialIcons);
                });
            }
        },

        check_social_icon_position: function($socialIcons) {
            if (($socialIcons.offset().top + $socialIcons.outerHeight()) <= ($(window).scrollTop() + $('#menu').outerHeight())) {
                $('.social-holder.sticky-header').addClass('show');
                $('#menu, #banner').addClass('social-hide');
            } else {
                $('.social-holder.sticky-header').removeClass('show');
                $('#menu, #banner').removeClass('social-hide');
            }
        },

        check_featured_social_icon_position: function($featuredSocialIcons) {
            var top = $(window).scrollTop() + 5;

            // If we are on too small of a screen we need to do some extra movement with the header
            if ($(window).width() < 1080 && $('.social-holder').offset().top <= top + $('#banner').outerHeight() + 15) {
                $('#banner a.logo_style').addClass('stuck');
            } else {
                $('#banner a.logo_style').removeClass('stuck');
            }
            if ($('.social-holder').offset().top <= top) {
                $featuredSocialIcons.addClass('stuck');
            } else {
                $featuredSocialIcons.removeClass('stuck');
            }
        },

        add_image_tags: function() {
            var urlRegex = /(^|\s+)(\b(https):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig,
                imgRegex = /\.(?:jpe?g|gif|png|tiff)$/i;
            $('.comment > .preview-holder > div.preview').each(function () {
                var $preview = $(this),
                    $preview_content = $preview.text();

                $preview_content.replace(urlRegex, function (match) {
                    match = match.trim();
                    imgRegex.lastIndex = 0;
                    if (imgRegex.test(match)) {
                        $preview.html($preview_content.replace(match, '</p><img src="' + match + '"><p>'));
                    } else {
                        $preview.html($preview_content.replace(match, '<a href="' + match + '" target="_blank" rel="nofollow">' + match + '</a>'));
                    }
                })
            })
        }
    };
    $(document).ready(function() {
        smg.common.add_image_tags();
    });

})(jQuery);
(function($) {

    var state = "closed",
        whenToOpen = 3,
        $menu;

    var menuResizer = function(){

        var $documentScroll = $(document).scrollTop();

        if($documentScroll > whenToOpen) {
            if(state == "open"){
                return;
            }

            $menu.addClass('shrunk');
            $menu.find('.search.open').removeClass('open');
            state = "open";

        } else {
            if(state == "closed"){
                return;
            }

            $menu.removeClass('shrunk');
            state = "closed";
        }
    };

    $(document).ready(function() {
        $menu = $('#menu').not('.no-resize');

        if($menu.length) {
            menuResizer();

            $(window).scroll(function() {
                menuResizer();
            });
        }
    });

})(jQuery);
/**
 * Refresh page after refreshTimeout,
 * if user has been idle for maxIdleTime
 * and the page is not currently visible
 *
 * Does not refresh if videos present
 */
(function ($) {
    window.Refresher = window.Refresher || {};

    $.extend(Refresher, {
        refreshTimeout : 300000,
        maxIdleTime    : 30000,
        doomsdayClock  : false,
        videoSelector  : 'iframe[src*=youtube], iframe[src*=soundcloud], iframe[src*=spotify], object[data*=spinmediavideo], iframe[src*=vimeo], object embed[src*=vevo]',
        blockForRefresh: false,

        init: function () {
            // Don't interrupt videos
            if (Refresher.doesPlayerExist()) {
                Refresher.trackEvent("no-refresh", "video exists");
                return;
            }

            // Start checking after initial interval
            window.setTimeout(function () {
                Refresher.startRefreshTimeout();

                // zero the idle timer on interaction
                $(document).on('mousemove keypress', function (e) {
                    Refresher.startRefreshTimeout();
                });
            }, Refresher.refreshTimeout);

        },

        startRefreshTimeout: function () {
            if(!Refresher.blockForRefresh) {
                clearTimeout(Refresher.doomsdayClock);
                Refresher.doomsdayClock = setTimeout(function () {
                    if (Refresher.isPageVisible()) {
                        Refresher.trackEvent("no-refresh", "page visible");
                        Refresher.startRefreshTimeout();
                    }
                    else {
                        Refresher.trackEvent("refresh", window.location.href);
                        Refresher.blockForRefresh = true;
                        // Give time to track event
                        setTimeout(function() {
                            window.location.href = window.location.href;
                        }, 10000);
                    }
                }, Refresher.maxIdleTime);
            }
        },

        isPageVisible: function () {
            return document.webkitVisibilityState == 'visible' || document.visibilityState == 'visible';
        },

        trackEvent: function (action, label) {
            if (typeof dataLayer != "undefined") {
                dataLayer.push({
                                   "event" : "AutoRefresh",
                                   "action": action,
                                   "label" : label
                               });
            }
        },

        doesPlayerExist: function () {
            // Checks to see if video/music players exist on the page
            return $('#content').find(Refresher.videoSelector).length > 0
        }
    }, true);
}(jQuery));

(function ($, pluginName) {
    var POSITION_TOP = 1,
        POSITION_BOTTOM = -1,
        POSITION_FIXED = 0;

    var scrollAttach = function($el, options){
        var self = this;
        
        self.inPosition = POSITION_TOP;
        self.bounds = {};
        self.defaultStyles = {
            'position': 'absolute',
            'top': 'auto',
            'bottom': 'auto'
        };
        self.relativeBounds = {
            'top': 0,
            'bottom': 0
        };
        self.scrollTop = 0;

        self.init = function() {
            defaults = {
                'top_padding': 80
            };
            self.options = _.extend(defaults, options);

            if(!self.options['$boundingEl'])
                return;

            self.on();
        };

        self.calcBounds = function() {
            self.elHeight = $el.outerHeight();
            self.bounds.top = self.options.$boundingEl.offset().top;
            self.bounds.bottom = self.bounds.top + self.options.$boundingEl.height();

            if(self.options['relativeBounds']) {
                _.extend(self.relativeBounds, self.options.relativeBounds);

                self.bounds.top += self.relativeBounds.top;
                self.bounds.bottom -= self.relativeBounds.bottom;
            }
        };

        self.fixedScroll = function(undo) {
            if (self.inPosition === POSITION_FIXED) {
                return;
            }
            self.fixStyles({
                'position': 'fixed',
                'top': self.options.top_padding + 'px'
            });

            self.inPosition = POSITION_FIXED;
        };

        self.fixStyles = function(css) {
            $el.css(_.extend({}, self.defaultStyles, css));
        };

        self.fixToBottom = function() {
            if (self.inPosition === POSITION_BOTTOM) {
                return;
            }
            self.fixStyles({ 'bottom': self.relativeBounds.bottom + 'px' });
            self.inPosition = POSITION_BOTTOM;
        };

        self.resetStyles = function() {
            self.inPosition = false;
        }

        self.fixToTop = function() {
            if (self.inPosition === POSITION_TOP) {
                return;
            }
            self.fixStyles({ 'top': self.relativeBounds.top + 'px' });
            self.inPosition = POSITION_TOP;
        };

        self.onScroll = function() {
            var scrollTop = $(document).scrollTop() + self.options.top_padding;


            if (scrollTop <= self.bounds.top) {
                $el.removeClass('smg-stuck');
                self.fixToTop();
            } else if (scrollTop + self.elHeight >= self.bounds.bottom) {
                $el.removeClass('smg-stuck');
                self.fixToBottom();
            } else {
                $el.addClass('smg-stuck');
                self.fixedScroll();
            }

            if(self.options['scrollCallback']) {
                var scrollDir = scrollTop > self.scrollTop ? 'down' : 'up';
                var offset = $el.offset();
                offset['bottom'] = offset.top + self.elHeight;
                offset['top'] -= self.options.top_padding;  // Do this after calculating bottom, or we have to add top padding back in
                self.options.scrollCallback(self, scrollDir, offset);
            }
            self.scrollTop = scrollTop;
        };

        self.off = function() {
            $(document).off(
                'scroll',
                self.onScroll
            );

            self.fixStyles({'position': 'initial'});
        };

        self.on = function() {
            self.calcBounds();
                
            $(document).on(
                'scroll', 
                self.onScroll
            );
            $(window).on(
                'resize',
                _.debounce(self.calcBounds, 100)
            ).on(
                'load', 
                self.calcBounds
            );
        };

        self.init();
    };
    

    $.fn[pluginName] = function(options) {
        return this.each(function(index, el){
            var $el = $(el);

            if(!$el.data(pluginName)) {
                $el.data(pluginName, new scrollAttach($el, options));
            } else if(_.isString(options)) {
                $el.data(pluginName)[options]();
            }
        });
    };
})(jQuery, 'smgScrollAttach');
(function($) {

    function scrollToHere(anchor) {
        // make the auto-scrolling interruptable on a user scroll
        var body = $('html, body');
        body.on("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove", function (){
            body.stop();
        });

        body.animate({
            scrollTop: $(anchor.replace('-sth', '')).offset().top - 75
            }, 1500,
            function() {
                body.off("scroll mousedown wheel DOMMouseScroll mousewheel keyup touchmove");
            });
        }

    // only scroll if user's navigating to comments
    $(document).ready(function () {
        if (location.hash.indexOf('-sth') > -1) {
            console.log("Will scroll");
            setTimeout(function(){
                scrollToHere(location.hash);
            }, 1000); // arbitrary delay to prevent "jump" to top of screen
        }
    });

})(jQuery);
(function ($) {
    /**
     *  Update or add a param to the URL
     *
     * @param url
     * @param paramName
     * @param paramValue
     * @returns string
     */
    window.addURLParam = function (url, paramName, paramValue) {
        var index = url.indexOf(paramName),
            hash_index = url.indexOf("#"),
            hash = "";

        // Save hash for later
        if (hash_index > -1) {
            hash = url.substring(hash_index);
            url = url.substring(0, hash_index);
        }

        // Update url with new value
        if (url.indexOf(paramName + "=") >= 0) {
            // update existing param
            var prefix = url.substring(0, index),
                suffix = url.substring(index);
            suffix = suffix.substring(suffix.indexOf("=") + 1);
            suffix = (suffix.indexOf("&") >= 0) ? suffix.substring(suffix.indexOf("&")) : "";
            url = prefix + paramName + "=" + paramValue + suffix;
        } else {
            // add new
            if (url.indexOf("?") < 0)
                url += "?" + paramName + "=" + paramValue;
            else
                url += "&" + paramName + "=" + paramValue;
        }
        return url + hash;
    };
}());
sharrre_track=function(t,e){"undefined"!=typeof dataLayer&&dataLayer.push({event:"track-social",action:t,label:e})},addURLParam=function(t,e,o){var n=t.indexOf(e),i=t.indexOf("#"),a="";if(i>-1&&(a=t.substring(i),t=t.substring(0,i)),t.indexOf(e+"=")>=0){var r=t.substring(0,n),s=t.substring(n);s=s.substring(s.indexOf("=")+1),s=s.indexOf("&")>=0?s.substring(s.indexOf("&")):"",t=r+e+"="+o+s}else t+=t.indexOf("?")<0?"?"+e+"="+o:"&"+e+"="+o;return t+a},function(t,o,n,i){function a(e,o){this.element=e,this.options=t.extend(!0,{},u,o),this.options.share=o.share,this._defaults=u,this._name=r,this.init()}var r="sharrre",u={className:"sharrre",share:{googlePlus:!1,facebook:!1,twitter:!1,digg:!1,delicious:!1,stumbleupon:!1,linkedin:!1,pinterest:!1,reddit:!1,email:!1,sms:!1,whatsapp:!1,tumblr:!1},shareTotal:0,template:"",title:"",url:n.location.href,utmSource:!1,text:n.title,urlCurl:"/wp-content/plugins/wp-pi-sharrre/sharrre.php",count:{},total:0,shorterTotal:!0,enableHover:!0,enableCounter:!0,enableTracking:!1,hover:function(){},hide:function(){},click:function(){},render:function(){},buttons:{googlePlus:{url:"",urlCount:!1,size:"medium",lang:"en-US",annotation:""},facebook:{url:"",urlCount:!1,action:"like",layout:"button_count",width:"",send:"false",faces:"false",colorscheme:"",font:"",lang:"en_US"},twitter:{url:"",urlCount:!1,count:"horizontal",hashtags:"",via:"",related:"",lang:"en"},digg:{url:"",urlCount:!1,type:"DiggCompact"},delicious:{url:"",urlCount:!1,size:"medium"},stumbleupon:{url:"",urlCount:!1,layout:"1"},linkedin:{url:"",urlCount:!1,counter:""},pinterest:{url:"",media:"",description:"",layout:"horizontal"},reddit:{url:"",urlCount:!1,layout:"1"},email:{url:"",urlCount:!1,layout:"1"},sms:{url:"",urlCount:!1,layout:"1"},whatsapp:{url:"",urlCount:!1,layout:"1"},tumblr:{url:"",urlCount:!1,layout:"1"}}},l={googlePlus:"",facebook:"https://graph.facebook.com/fql?q=SELECT%20url,%20normalized_url,%20share_count,%20like_count,%20comment_count,%20total_count,commentsbox_count,%20comments_fbid,%20click_count%20FROM%20link_stat%20WHERE%20url=%27{url}%27&callback=?",twitter:"http://cdn.api.twitter.com/1/urls/count.json?url={url}&callback=?",digg:"http://services.digg.com/2.0/story.getInfo?links={url}&type=javascript&callback=?",delicious:"http://feeds.delicious.com/v2/json/urlinfo/data?url={url}&callback=?",stumbleupon:"",linkedin:"http://www.linkedin.com/countserv/count/share?format=jsonp&url={url}&callback=?",pinterest:"http://api.pinterest.com/v1/urls/count.json?url={url}&callback=?",reddit:"http://buttons.reddit.com/button_info.json?url={url}"},c={googlePlus:function(e){var i=e.options.buttons.googlePlus;t(e.element).find(".buttons").append('<div class="button googleplus"><div class="g-plusone" data-size="'+i.size+'" data-href="'+(""!==i.url?i.url:e.options.url)+'" data-annotation="'+i.annotation+'"></div></div>'),o.___gcfg={lang:e.options.buttons.googlePlus.lang};var a=0;"undefined"==typeof gapi&&0==a?(a=1,function(){var t=n.createElement("script");t.type="text/javascript",t.async=!0,t.src="//apis.google.com/js/plusone.js";var e=n.getElementsByTagName("script")[0];e.parentNode.insertBefore(t,e)}()):gapi.plusone.go()},facebook:function(e){var o=e.options.buttons.facebook;t(e.element).find(".buttons").append('<div class="button facebook"><div id="fb-root"></div><div class="fb-like" data-href="'+(""!==o.url?o.url:e.options.url)+'" data-send="'+o.send+'" data-layout="'+o.layout+'" data-width="'+o.width+'" data-show-faces="'+o.faces+'" data-action="'+o.action+'" data-colorscheme="'+o.colorscheme+'" data-font="'+o.font+'" data-via="'+o.via+'"></div></div>');var i=0;"undefined"==typeof FB&&0==i?(i=1,function(t,e,n){var i,a=t.getElementsByTagName(e)[0];t.getElementById(n)||(i=t.createElement(e),i.id=n,i.src="//connect.facebook.net/"+o.lang+"/all.js#xfbml=1",a.parentNode.insertBefore(i,a))}(n,"script","facebook-jssdk")):FB.XFBML.parse()},twitter:function(e){var o=e.options.buttons.twitter;t(e.element).find(".buttons").append('<div class="button twitter"><a href="https://twitter.com/share" class="twitter-share-button" data-url="'+(""!==o.url?o.url:e.options.url)+'" data-count="'+o.count+'" data-text="'+e.options.text+'" data-via="'+o.via+'" data-hashtags="'+o.hashtags+'" data-related="'+o.related+'" data-lang="'+o.lang+'">Tweet</a></div>');var i=0;"undefined"==typeof twttr&&0==i?(i=1,function(){var t=n.createElement("script");t.type="text/javascript",t.async=!0,t.src="//platform.twitter.com/widgets.js";var e=n.getElementsByTagName("script")[0];e.parentNode.insertBefore(t,e)}()):t.ajax({url:"//platform.twitter.com/widgets.js",dataType:"script",cache:!0})},digg:function(e){var o=e.options.buttons.digg;t(e.element).find(".buttons").append('<div class="button digg"><a class="DiggThisButton '+o.type+'" rel="nofollow external" href="http://digg.com/submit?url='+encodeURIComponent(""!==o.url?o.url:e.options.url)+'"></a></div>');var i=0;"undefined"==typeof __DBW&&0==i&&(i=1,function(){var t=n.createElement("SCRIPT"),e=n.getElementsByTagName("SCRIPT")[0];t.type="text/javascript",t.async=!0,t.src="//widgets.digg.com/buttons.js",e.parentNode.insertBefore(t,e)}())},delicious:function(e){if("tall"==e.options.buttons.delicious.size)var o="width:50px;",n="height:35px;width:50px;font-size:15px;line-height:35px;",i="height:18px;line-height:18px;margin-top:3px;";else var o="width:93px;",n="float:right;padding:0 3px;height:20px;width:26px;line-height:20px;",i="float:left;height:20px;line-height:20px;";var a=e.shorterTotal(e.options.count.delicious);"undefined"==typeof a&&(a=0),t(e.element).find(".buttons").append('<div class="button delicious"><div style="'+o+'font:12px Arial,Helvetica,sans-serif;cursor:pointer;color:#666666;display:inline-block;float:none;height:20px;line-height:normal;margin:0;padding:0;text-indent:0;vertical-align:baseline;"><div style="'+n+'background-color:#fff;margin-bottom:5px;overflow:hidden;text-align:center;border:1px solid #ccc;border-radius:3px;">'+a+'</div><div style="'+i+'display:block;padding:0;text-align:center;text-decoration:none;width:50px;background-color:#7EACEE;border:1px solid #40679C;border-radius:3px;color:#fff;"><img src="http://www.delicious.com/static/img/delicious.small.gif" height="10" width="10" alt="Delicious" /> Add</div></div></div>'),t(e.element).find(".delicious").on("click",function(){e.openPopup("delicious")})},stumbleupon:function(e){var i=e.options.buttons.stumbleupon;t(e.element).find(".buttons").append('<div class="button stumbleupon"><su:badge layout="'+i.layout+'" location="'+(""!==i.url?i.url:e.options.url)+'"></su:badge></div>');var a=0;"undefined"==typeof STMBLPN&&0==a?(a=1,function(){var t=n.createElement("script");t.type="text/javascript",t.async=!0,t.src="//platform.stumbleupon.com/1/widgets.js";var e=n.getElementsByTagName("script")[0];e.parentNode.insertBefore(t,e)}(),s=o.setTimeout(function(){"undefined"!=typeof STMBLPN&&(STMBLPN.processWidgets(),clearInterval(s))},500)):STMBLPN.processWidgets()},linkedin:function(e){var i=e.options.buttons.linkedin;t(e.element).find(".buttons").append('<div class="button linkedin"><script type="in/share" data-url="'+(""!==i.url?i.url:e.options.url)+'" data-counter="'+i.counter+'"></script></div>');var a=0;"undefined"==typeof o.IN&&0==a?(a=1,function(){var t=n.createElement("script");t.type="text/javascript",t.async=!0,t.src="//platform.linkedin.com/in.js";var e=n.getElementsByTagName("script")[0];e.parentNode.insertBefore(t,e)}()):o.IN.init()},pinterest:function(e){var o=e.options.buttons.pinterest;t(e.element).find(".buttons").append('<div class="button pinterest"><a href="http://pinterest.com/pin/create/button/?url='+(""!==o.url?o.url:e.options.url)+"&media="+o.media+"&description="+o.description+'" class="pin-it-button" count-layout="'+o.layout+'">Pin It</a></div>'),function(){var t=n.createElement("script");t.type="text/javascript",t.async=!0,t.src="//assets.pinterest.com/js/pinit.js";var e=n.getElementsByTagName("script")[0];e.parentNode.insertBefore(t,e)}()},reddit:function(){},email:function(){},sms:function(){},whatsapp:function(){},tumblr:function(){}},d={googlePlus:function(){},facebook:function(){fb=o.setInterval(function(){"undefined"!=typeof FB&&(FB.Event.subscribe("edge.create",function(t){sharrre_track("facebook","like",t)}),FB.Event.subscribe("edge.remove",function(t){sharrre_track("facebook","unlike",t)}),FB.Event.subscribe("message.send",function(t){sharrre_track("facebook","send",t)}),clearInterval(fb))},1e3)},twitter:function(){tw=o.setInterval(function(){"undefined"!=typeof twttr&&(twttr.events.bind("tweet",function(t){t&&sharrre_track("twitter","tweet")}),clearInterval(tw))},1e3)},digg:function(){},delicious:function(){},stumbleupon:function(){},linkedin:function(){},pinterest:function(){},reddit:function(){},email:function(){},sms:function(){},whatsapp:function(){},tumblr:function(){}},p={googlePlus:function(t){var e=""!==t.buttons.googlePlus.url?t.buttons.googlePlus.url:t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("https://plus.google.com/share?hl="+t.buttons.googlePlus.lang+"&url="+encodeURIComponent(e),"","toolbar=0, status=0, width=515, height=475")},facebook:function(t){var e=""!==t.buttons.facebook.url?t.buttons.facebook.url:t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("http://www.facebook.com/sharer/sharer.php?u="+encodeURIComponent(e),"","toolbar=0, status=0, width=600, height=500")},twitter:function(t){var e=""!==t.buttons.twitter.url?t.buttons.twitter.url:t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("https://twitter.com/intent/tweet?text="+encodeURIComponent(t.text)+"&url="+encodeURIComponent(e)+(""!==t.buttons.twitter.via?"&via="+t.buttons.twitter.via:""),"","toolbar=0, status=0, width=650, height=360")},digg:function(t){var e=""!==t.buttons.digg.url?t.buttons.digg.url:t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("http://digg.com/tools/diggthis/submit?url="+encodeURIComponent(e)+"&title="+t.text+"&related=true&style=true","","toolbar=0, status=0, width=650, height=360")},delicious:function(t){var e=""!==t.buttons.delicious.url?t.buttons.delicious.url:t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("http://www.delicious.com/save?v=5&noui&jump=close&url="+encodeURIComponent(e)+"&title="+t.text,"delicious","toolbar=no,width=550,height=550")},stumbleupon:function(t){var e=""!==t.buttons.stumbleupon.url?t.buttons.stumbleupon.url:t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("http://www.stumbleupon.com/badge/?url="+encodeURIComponent(e),"stumbleupon","toolbar=no,width=550,height=550")},linkedin:function(t){var e=""!==t.buttons.linkedin.url?t.buttons.linkedin.url:t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("https://www.linkedin.com/cws/share?url="+encodeURIComponent(e)+"&token=&isFramed=true","linkedin","toolbar=no,width=550,height=550")},pinterest:function(t){var e=""!==t.buttons.pinterest.url?t.buttons.pinterest.url:t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("http://pinterest.com/pin/create/button/?url="+encodeURIComponent(e)+"&media="+encodeURIComponent(t.media)+"&description="+t.text,"pinterest","toolbar=no,width=700,height=300")},reddit:function(t){var e=t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("http://www.reddit.com/submit?url="+encodeURIComponent(e)+"&title="+encodeURIComponent(n.title),"reddit","toolbar=no,width=850,height=615")},email:function(t){var e=t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.location.href="mailto:?subject="+encodeURIComponent(t.text)+"&body=Article: "+encodeURIComponent(e)},sms:function(t){var e=t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button");var n="sms:;body=";/Android/i.test(navigator.userAgent)?n="sms:?body=Check out this article: ":/iPhone|iPad|iPod/i.test(navigator.userAgent)&&(n="sms:&body=Check out this article: "),o.location.href=n+encodeURIComponent(e)},whatsapp:function(t){var e=t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.location.href="whatsapp://send?text="+encodeURIComponent(e)},tumblr:function(t){var e=t.url;e=addURLParam(e,"utm_source",t.utmSource),e=addURLParam(e,"utm_medium","button"),o.open("https://www.tumblr.com/widgets/share/tool?canonicalUrl="+encodeURIComponent(e)+"&title="+encodeURIComponent(n.title),"tumblr","toolbar=no,width=540,height=682")}};a.prototype.init=function(){var e=this;""!==this.options.urlCurl&&(l.googlePlus=this.options.urlCurl+"?url={url}&type=googlePlus",l.stumbleupon=this.options.urlCurl+"?url={url}&type=stumbleupon"),t(this.element).addClass(this.options.className),t.each(t(this.element).data(),function(t,o){var n=t.indexOf(".");if(n>-1){var i=t.slice(0,n),a=t.slice(n+1);t=i,e.options[i]=e.options[i]||{},e.options[i][a]=o}else e.options[t]=o}),t.each(this.options.share,function(t,o){o===!0&&e.options.shareTotal++}),e.options.enableCounter===!0?t.each(this.options.share,function(t,o){if(o===!0)try{e.getSocialJson(t)}catch(n){}}):""!==e.options.template?(e.renderer(),e.rendererPerso()):this.loadButtons(),t(this.element).hover(function(){0===t(this).find(".buttons").length&&e.options.enableHover===!0&&e.loadButtons(),e.options.hover(e,e.options)},function(){e.options.hide(e,e.options)}),t(this.element).click(function(t){return e.options.click(e,e.options,t),!1})},a.prototype.loadButtons=function(){var e=this;t(this.element).append('<div class="buttons"></div>'),t.each(e.options.share,function(t,o){1==o&&(c[t](e),e.options.enableTracking===!0&&d[t]())})},a.prototype.getSocialJson=function(e){var o=this,n=0,i=l[e].replace("{url}",encodeURIComponent(this.options.url));this.options.buttons[e].urlCount===!0&&""!==this.options.buttons[e].url&&(i=l[e].replace("{url}",this.options.buttons[e].url)),""!=i&&""!==o.options.urlCurl?t.getJSON(i,function(t){if("undefined"!=typeof t.count){var i=t.count+"";i=i.replace("Â ",""),n+=parseInt(i,10)}else t.data&&t.data.length>0&&"undefined"!=typeof t.data[0].total_count?n+=parseInt(t.data[0].total_count,10):"undefined"!=typeof t[0]&&t[0].total_posts?n+=parseInt(t[0].total_posts,10):"undefined"!=typeof t.data&&"undefined"!=typeof t.data.children&&"undefined"!=typeof t.data.children[0]&&(n+=t.data.children[0].data.score);o.options.count[e]=n,o.options.total+=n,o.renderer(),o.rendererPerso()}).error(function(){o.options.count[e]=0,o.rendererPerso()}):(o.renderer(),o.options.count[e]=0,o.rendererPerso())},a.prototype.rendererPerso=function(){var t=0;for(e in this.options.count)t++;t===this.options.shareTotal&&this.options.render(this,this.options)},a.prototype.renderer=function(){var e=this.options.total,o=this.options.template;this.options.shorterTotal===!0&&(e=this.shorterTotal(e)),0==this.options.total&&t(this.element).addClass("not-shared"),""!==o?(o=o.replace("{total}",e),o=o.replace("{title}",this.options.title),t(this.element).html(o)):t(this.element).html('<div class="box"><a class="count" href="#">'+e+"</a>"+(""!==this.options.title?'<a class="share" href="#">'+this.options.title+"</a>":"")+"</div>")},a.prototype.shorterTotal=function(t){return t>=1e6?t=(t/1e6).toFixed(2)+"M":t>=1e3&&(t=(t/1e3).toFixed(1)+"k"),t},a.prototype.openPopup=function(t){if(p[t](this.options),this.options.enableTracking===!0){var e={googlePlus:{site:"Google",action:"+1"},facebook:{site:"facebook",action:"share"},twitter:{site:"twitter",action:"tweet"},digg:{site:"digg",action:"add"},delicious:{site:"delicious",action:"add"},stumbleupon:{site:"stumbleupon",action:"add"},linkedin:{site:"linkedin",action:"share"},pinterest:{site:"pinterest",action:"pin"},reddit:{site:"reddit",action:"add"},email:{site:"email",action:"send"},sms:{site:"sms",action:"text"},whatsapp:{site:"whatsapp",action:"send"},tumblr:{site:"tumblr",action:"send"}};sharrre_track(e[t].site,e[t].action,location.href)}},a.prototype.simulateClick=function(){var e=t(this.element).html();t(this.element).html(e.replace(this.options.total,this.options.total+1))},a.prototype.update=function(t,e){""!==t&&(this.options.url=t),""!==e&&(this.options.text=e)},t.fn[r]=function(e){var o=arguments;return e===i||"object"==typeof e?this.each(function(){t.data(this,"plugin_"+r)||t.data(this,"plugin_"+r,new a(this,e))}):"string"==typeof e&&"_"!==e[0]&&"init"!==e?this.each(function(){var n=t.data(this,"plugin_"+r);n instanceof a&&"function"==typeof n[e]&&n[e].apply(n,Array.prototype.slice.call(o,1))}):void 0}}(jQuery,window,document);
var smg=smg||{};smg.common=smg.common||{},function(e,r){e.fn.sharrre&&(r.common.init_sharrre=function(r,a,t,n){var r=r||".social-icons",s=e(r),o=["facebook","googlePlus","pinterest","reddit","stumbleupon","twitter","email","sms","whatsapp","tumblr"],i={enableHover:!1,template:'<div><span class="icon-social"></span><span class="sharrre-title">{title}</span></div>',share:{},enableTracking:!0,enableCounter:!1};e(".featured-embed-holder .js-main-image-slider--prev").length&&s.addClass("small"),t&&n&&(i.url=t,i.title=n);for(var l=0;l<o.length;l++){var m=e.extend(!0,{},i),c=o[l],d=s.find("."+c);m.share[c]=!0,m.click=function(e,r,a){return a.stopPropagation(),e.openPopup(Object.keys(r.share)[0]),!1},a&&(t&&n&&d.removeData("url").removeData("title").removeAttr("data-url").removeAttr("data-title").off("click"),d.removeData("plugin_sharrre").empty()),d.sharrre(m)}s.data("sharrre-rendered",!0)},e(document).ready(function(){r.common.init_sharrre()}))}(jQuery,smg);