var smg = smg || {};
smg['sp'] = smg['sp'] || {};

(function($, sp, common){

    sp.common = {

        init: function() {
            common.init_search_hover();
            common.init_social();
            common.init_social_scrolling();

            sp.common.init_carousel_pagination();
            if(!smg.isTouch) {
                sp.common.init_feed_hovers();
            }
        },

        init_feed_hovers: function() {
            var $posts = $('.left-col .feed-split-image .post');

            if($posts.length) {
                $posts.each(function(){
                    var $this = $(this);

                    $this.find('.image-holder, h2')
                        .hover(
                            function() { $this.addClass('show-overlay'); },
                            function() { $this.removeClass('show-overlay'); }
                        );
                });
            }
        },

        init_carousel_pagination : function() {
            var $reviewCar = $('.carousel-widget-reviews'),
                $pagCar = $('.carousel-widget-review-pagination');

            $reviewCar.on('beforeChange', function(e, slick, currentSlide, nextSlide){
                $pagCar.find('.carousel-slide')
                    .removeClass('current')
                    .eq(nextSlide)
                    .addClass('current');
            });
        },
         hover_color: function(slidenumber){
             var $slide = $(".carousel-slide:nth-child("+slidenumber+")");

             $slide.on('mouseover', function () {
                 $slide.find("a").css('color', '#e51937');
                 $slide.find(".text-holder").css('border-color', '#e51937');
             }).on('mouseout', function () {
                 $slide.find("a").css('color', '#333');
                 $slide.find(".text-holder").css('border-color', '#333');
             });
         }
    };

    $(document).ready(function(){ 
        sp.common.init(); 
        CLARITY.push({
            use: ['ads'],
            run : function(Ads){
                setTimeout(function(){
                    smg.common.init_ad_scrolling(Ads);
                }, 2000);
            }
        });

        sp.common.hover_color(1);
        sp.common.hover_color(2);
        sp.common.hover_color(3);

    });

})(jQuery, smg.sp, smg.common);

var smg = smg || {};
smg['common'] = smg['common'] || {};

(function($, smg){
    if (!$.fn.sharrre) {
        return;
    }

    smg.common.init_sharrre = function (holder, refresh, url, title) {
        var holder = holder || '.social-icons';
        var $socialHolder = $(holder), 
            socialTypes = [
                'facebook',
                'googlePlus',
                'pinterest',
                'reddit',
                'stumbleupon',
                'twitter',
                'email',
                'sms',
                'whatsapp',
                'tumblr'
            ],
            sharrreDefaults = {
                enableHover: false,
                template: '<div><span class="icon-social"></span><span class="sharrre-title">{title}</span></div>',
                share: {},
                enableTracking: true,
                enableCounter: false
            };

        // Look for gallery arrow
        if ($('.featured-embed-holder .js-main-image-slider--prev').length) {
            $socialHolder.addClass('small');
        }

        // If passed in use them
        if (url && title) {
            sharrreDefaults['url'] = url;
            sharrreDefaults['title'] = title;
        }

        for (var i = 0; i < socialTypes.length; i++) {
            var defaults = $.extend(true, {}, sharrreDefaults),
                platform = socialTypes[i],
                $socialIcon = $socialHolder.find('.' + platform);

            defaults['share'][platform] = true;
            defaults['click'] = function(api, options, e) {
                e.stopPropagation();
                api.openPopup(Object.keys(options.share)[0]);
                return false;
            };

            // If refresh, clear old sharrre plugin
            // have to clear all of this crap b/c the plugin is a POS
            if (refresh) {
                if (url && title) {
                    $socialIcon
                        .removeData('url')
                        .removeData('title')
                        .removeAttr('data-url')
                        .removeAttr('data-title')
                        .off('click');
                }

                $socialIcon.removeData('plugin_sharrre').empty();
            }
            $socialIcon.sharrre(defaults);
        }
        $socialHolder.data('sharrre-rendered', true);   
    }

    $(document).ready(function() {
        smg.common.init_sharrre();
    });
})(jQuery, smg);
