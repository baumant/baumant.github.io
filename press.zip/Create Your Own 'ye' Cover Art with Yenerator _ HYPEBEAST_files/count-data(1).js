var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0","multiple":"{num}","one":"1"}},"counts":[{"id":"https:\/\/hypebeast.com\/2019\/2\/tomokazu-matsuyama-studio-visit-video-interview","comments":4},{"id":"https:\/\/hypebeast.com\/2019\/1\/cactus-plant-flea-born-again-19-hoodie-kanye-west","comments":29}]});
}